import os

template = """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ALEXA | {{TITLE}}</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,400&family=Montserrat:wght@200;300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --purple: #9A79FF;
            --purple-glow: rgba(154, 121, 255, 0.4);
            --bg-dark: #050505;
            --card-bg: #0d0d0d;
            --font-serif: 'Cormorant Garamond', serif;
            --font-sans: 'Montserrat', sans-serif;
            --ease-out: cubic-bezier(0.2, 1, 0.3, 1);
        }

        html { scroll-behavior: smooth; }
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        
        body { 
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(circle at 50% 0%, #1a0b2e 0%, var(--bg-dark) 70%),
                url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
            color: #f5f5f5; font-family: var(--font-sans); 
            padding-top: 100px; overflow-x: hidden; height: 100vh; overflow-y: hidden; 
        }

        body::before {
            content: ''; position: fixed; inset: 0;
            background: radial-gradient(circle at 20% 30%, rgba(154, 121, 255, 0.05) 0%, transparent 40%),
                        radial-gradient(circle at 80% 70%, rgba(154, 121, 255, 0.05) 0%, transparent 40%);
            pointer-events: none; z-index: 1;
        }

        body.loaded { height: auto; overflow-y: auto; padding-bottom: 100px; }

        #loader {
            position: fixed; inset: 0; background: var(--bg-dark); z-index: 10000;
            display: flex; justify-content: center; align-items: center;
            transition: opacity 1s var(--ease-out), visibility 1s;
        }
        .loader-word {
            font-family: var(--font-serif); font-size: 3rem; font-style: italic; 
            letter-spacing: 8px; color: var(--purple); animation: fadeAnim 2.5s infinite;
        }       
        @keyframes fadeAnim { 0%, 100% { opacity: 0; filter: blur(5px); transform: translateY(5px); } 50% { opacity: 1; filter: blur(0); transform: translateY(0); } }
        body.loaded #loader { opacity: 0; visibility: hidden; pointer-events: none; }

        .header {
            position: fixed; top: 0; left: 0; width: 100%; height: 80px;
            background: rgba(5, 5, 5, 0.85); backdrop-filter: blur(20px);
            display: flex; justify-content: space-between; align-items: center;
            padding: 0 5%; z-index: 1000; border-bottom: 1px solid rgba(154, 121, 255, 0.15);
            transform: translateY(-100%); transition: transform 0.8s var(--ease-out);
        }
        body.loaded .header { transform: translateY(0); }

        .logo { font-family: var(--font-serif); font-size: 1.6rem; letter-spacing: 6px; color: #fff; text-decoration: none; }
        .logo span { color: var(--purple); text-shadow: 0 0 10px var(--purple-glow); }

        .cart-trigger { position: relative; font-size: 1.4rem; color: #fff; cursor: pointer; transition: 0.3s; }
        .cart-trigger:hover { color: var(--purple); transform: scale(1.1); }
        .cart-count {
            position: absolute; top: -8px; right: -10px; background: var(--purple); color: #000;
            font-size: 0.7rem; font-weight: 800; width: 18px; height: 18px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; opacity: 0; transform: scale(0.5);
            transition: 0.4s var(--ease-out);
        }
        .cart-count.active { opacity: 1; transform: scale(1); }

        .hero { text-align: center; margin: 40px 0 60px; opacity: 0; transform: translateY(20px); transition: 1s var(--ease-out); }
        body.loaded .hero { opacity: 1; transform: translateY(0); }
        .hero h1 { font-family: var(--font-serif); font-size: 3rem; color: var(--purple); font-style: italic; font-weight: 300; }
        .hero::after { content: ''; display: block; width: 40px; height: 1px; background: var(--purple); margin: 15px auto; opacity: 0.6; }

        .products-grid {
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 25px; padding: 0 6% 120px; max-width: 1400px; margin: 0 auto;
            opacity: 0; transition: 1.2s var(--ease-out);
        }
        @media (max-width: 500px) { .products-grid { grid-template-columns: repeat(2, 1fr); gap: 15px; padding: 0 15px 100px; } }
        body.loaded .products-grid { opacity: 1; }

        .card {
            background: var(--card-bg); border: 1px solid rgba(154, 121, 255, 0.08);
            display: flex; flex-direction: column; overflow: hidden; position: relative;
            transition: 0.5s var(--ease-out); border-radius: 20px; cursor: pointer;
        }
        .card:hover { transform: translateY(-10px); border-color: rgba(154, 121, 255, 0.3); box-shadow: 0 20px 40px rgba(0,0,0,0.6); }

        .card-img-box { width: 100%; aspect-ratio: 1/1.1; overflow: hidden; }
        .card-img { width: 100%; height: 100%; object-fit: cover; transition: 0.8s var(--ease-out); }
        .card:hover .card-img { transform: scale(1.08); }

        .card-info { padding: 15px 10px; text-align: center; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; }
        .card-title { font-family: var(--font-serif); font-size: 0.95rem; color: #fff; text-transform: uppercase; margin-bottom: 8px; letter-spacing: 1px; }
        .card-price span { color: var(--purple); font-weight: 600; }

        .btn-zone { width: 100%; border-top: 1px solid rgba(154, 121, 255, 0.1); min-height: 50px; display: flex; align-items: center; justify-content: center;}
        .btn-add { width: 100%; height: 50px; background: transparent; border: none; color: var(--purple); text-transform: uppercase; font-size: 0.75rem; cursor: pointer; font-weight: 300; transition: 0.4s; }
        .btn-add:hover { background: rgba(154, 121, 255, 0.05); letter-spacing: 2px; }
        
        .qty-selector { display: flex; justify-content: space-between; align-items: center; width: 100%; height: 50px; padding: 0 15px; background: rgba(154, 121, 255, 0.08); }
        .qty-selector button { width: 30px; height: 30px; border-radius: 50%; border: 1px solid rgba(154, 121, 255, 0.4); background: transparent; color: #fff; cursor: pointer; display: grid; place-items: center; transition: 0.3s; }
        .qty-selector button:hover { border-color: var(--purple); background: rgba(154, 121, 255, 0.1); }
        
        .float-pill { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%) translateY(200%); width: 92%; max-width: 420px; background: rgba(10,10,10,0.95); backdrop-filter: blur(15px); border: 1px solid rgba(154, 121, 255, 0.4); border-radius: 60px; padding: 8px 8px 8px 30px; display: flex; justify-content: space-between; align-items: center; z-index: 1500; transition: 0.6s cubic-bezier(0.34, 1.56, 0.64, 1); box-shadow: 0 15px 40px rgba(0,0,0,0.8); }
        .float-pill.active { transform: translateX(-50%) translateY(0); }
        .pill-btn { background: var(--purple); color: #000; border: none; padding: 12px 35px; border-radius: 40px; font-weight: 800; font-size: 0.85rem; cursor: pointer; text-transform: uppercase; }

        .cart-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.85); opacity: 0; pointer-events: none; transition: 0.4s; z-index: 1999; }
        .cart-overlay.open { opacity: 1; pointer-events: all; }
        .cart-sidebar { position: fixed; top: 0; right: 0; width: 85%; max-width: 420px; height: 100%; background: #080808; border-left: 1px solid rgba(154,121,255,0.2); transform: translateX(100%); transition: 0.6s var(--ease-out); z-index: 2000; display: flex; flex-direction: column; }
        .cart-sidebar.open { transform: translateX(0); }
        .cart-items { flex: 1; overflow-y: auto; padding: 25px 20px; }
        .cart-item { display: flex; gap: 15px; margin-bottom: 25px; border-bottom: 1px solid rgba(154,121,255,0.05); padding-bottom: 20px; }
        .item-img { width: 65px; height: 65px; object-fit: cover; border-radius: 10px; }
        
        .cart-footer { padding: 30px 20px; background: #050505; border-top: 1px solid rgba(154,121,255,0.1); }
        .btn-wa { width: 100%; padding: 18px; background: var(--purple); border: none; border-radius: 15px; font-weight: 800; cursor: pointer; color: #000; text-transform: uppercase; letter-spacing: 2px; }

        .modal-wa { position: fixed; inset: 0; background: rgba(0,0,0,0.92); display: flex; justify-content: center; align-items: center; opacity: 0; pointer-events: none; z-index: 3000; transition: 0.4s; }
        .modal-wa.active { opacity: 1; pointer-events: all; }
        .wa-box { background: #0d0d0d; border: 1px solid var(--purple); padding: 40px 30px; text-align: center; width: 320px; border-radius: 25px; }
        .wa-link { display: flex; align-items: center; justify-content: center; gap: 10px; padding: 15px; border: 1px solid rgba(154,121,255,0.2); margin: 12px 0; color: #fff; text-decoration: none; border-radius: 12px; transition: 0.3s; }
        .wa-link:hover { background: var(--purple); color: #000; }

        .product-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.98); display: flex; justify-content: center; align-items: center; opacity: 0; pointer-events: none; z-index: 4000; transition: 0.4s; padding: 20px; }
        .product-modal.active { opacity: 1; pointer-events: all; }
        .product-modal-content { background: #0a0a0a; border: 1px solid rgba(154, 121, 255, 0.3); width: 100%; max-width: 480px; position: relative; border-radius: 30px; overflow: hidden; display: flex; flex-direction: column; }
        .close-product { position: absolute; top: 15px; right: 15px; background: rgba(0,0,0,0.6); border: none; color: #fff; width: 38px; height: 38px; border-radius: 50%; cursor: pointer; z-index: 10; display: grid; place-items: center; }
        .modal-img { width: 100%; aspect-ratio: 1/1; object-fit: cover; }
        .modal-body { padding: 35px 30px; text-align: center; }
        .modal-name { font-family: var(--font-serif); font-size: 1.8rem; color: var(--purple); margin-bottom: 12px; font-style: italic; }
        .modal-description { font-size: 0.95rem; color: #888; margin-bottom: 20px; line-height: 1.5; }
        .modal-cost { font-size: 1.4rem; color: #fff; margin-bottom: 25px; font-weight: 600; }
    </style>
<script src="metrics.js"></script>
</head>
<body>
    <div id="loader"><span class="loader-word">{{LOADER}}</span></div>
    <header class="header">
        <a href="{{HOME_LINK}}" class="logo">ALEXA<span>.</span></a>
        <div class="cart-trigger" onclick="toggleCart(true)">
            <i class="fa-solid fa-bag-shopping"></i>
            <span class="cart-count" id="cartCount">0</span>
        </div>
    </header>
    <main>
        <section class="hero">
            <h1>{{HERO_H1}}</h1>
        </section>
        <div class="products-grid" id="grid"></div>
    </main>
    <div class="float-pill" id="floatPill">
        <div class="pill-total">Total: <span id="pillTotalText">L. 0</span></div>
        <button class="pill-btn" onclick="toggleCart(true)">Ver Bolsa</button>
    </div>
    <div class="cart-overlay" id="cartOverlay" onclick="toggleCart(false)"></div>
    <div class="cart-sidebar" id="cartSidebar">
        <div style="padding: 30px 20px; border-bottom: 1px solid rgba(154,121,255,0.1); display: flex; justify-content: space-between; align-items: center;">
            <h2 style="font-family: var(--font-serif); font-size: 1.8rem; font-style: italic;">Mi Selección</h2>
            <button onclick="toggleCart(false)" style="background:none; border:none; color:#fff; font-size:1.5rem;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="cart-items" id="cartItems"></div>
        <div class="cart-footer">
            <div style="display: flex; justify-content: space-between; margin-bottom: 25px; font-family: var(--font-serif); font-size: 1.4rem;">
                <span>Total</span>
                <span id="cartTotal" style="color: var(--purple);">L. 0</span>
            </div>
            <button class="btn-wa" onclick="openWaModal()">Finalizar por WhatsApp</button>
        </div>
    </div>
    <div id="modalWa" class="modal-wa">
        <div class="wa-box">
            <h3 style="font-family: var(--font-serif); font-size: 1.8rem; margin-bottom: 10px; color: var(--purple);">Contactar Asesora</h3>
            <a href="#" onclick="sendToWA('50497320939')" class="wa-link"><i class="fab fa-whatsapp"></i> Asesora I</a>
            <a href="#" onclick="sendToWA('50499226664')" class="wa-link"><i class="fab fa-whatsapp"></i> Asesora II</a>
            <button onclick="closeWaModal()" style="background:none; border:none; color:#555; margin-top:15px;">Volver</button>
        </div>
    </div>
    <div id="productModal" class="product-modal">
        <div class="product-modal-content" id="modalContent"></div>
    </div>
    <script>
        const SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vT_GLYKFFT9BTUnGoYIxsK8x24006DuflBHsz0GOzhdk1lcF_oS7Id4zV1kax0EH_9VQmrmLH6uVitC/pub?output=csv";
        let products = Array(12).fill({}).map((_, i) => ({
            id: `{{PREFIX}}${i+1}`,
            name: "Cargando...",
            price: 0,
            img: "https://via.placeholder.com/400x500?text=ALEXA",
            stock: false,
            category: "{{CATEGORY}}",
            desc: ""
        }));
        let cart = JSON.parse(localStorage.getItem('{{STORAGE_KEY}}')) || {};
        async function loadProducts() {
            try {
                const response = await fetch(SHEET_CSV_URL);
                const data = await response.text();
                const rows = data.split(/\\r?\\n/).slice(1);
                const parsed = rows.map(row => {
                    const col = row.match(/(".*?"|[^",\\s]+)(?=\\s*,|\\s*$)/g);
                    if (!col) return null;
                    const clean = (str) => str ? str.replace(/^"|"$/g, '').trim() : '';
                    return {
                        id: clean(col[0]),
                        name: clean(col[1]),
                        price: parseFloat(clean(col[2])) || 0,
                        img: clean(col[3]),
                        stock: clean(col[4]).toLowerCase() === 'true',
                        category: clean(col[5]),
                        desc: clean(col[6]) || "Colección exclusiva Alexa."
                    };
                }).filter(p => p && p.name && p.stock && p.category === "{{CATEGORY}}");
                if (parsed.length > 0) products = parsed;
                renderGrid();
            } catch (e) { console.error(e); renderGrid(); }
        }
        function renderGrid() {
            const grid = document.getElementById('grid');
            if (!grid) return;
            grid.innerHTML = products.map(p => {
                const qty = cart[p.id] || 0;
                return `
                    <div class="card" onclick="openProductModal('${p.id}')">
                        <div class="card-img-box"><img src="${p.img}" class="card-img"></div>
                        <div class="card-info">
                            <h3 class="card-title">${p.name}</h3>
                            <p class="card-price">L. <span>${p.price.toLocaleString()}</span></p>
                        </div>
                        <div class="btn-zone" onclick="event.stopPropagation()">
                            ${qty > 0 ? `
                                <div class="qty-selector">
                                    <button onclick="updateCart('${p.id}', -1)"><i class="fa-solid fa-minus"></i></button>
                                    <span>${qty}</span>
                                    <button onclick="updateCart('${p.id}', 1)"><i class="fa-solid fa-plus"></i></button>
                                </div>
                            ` : `
                                <button class="btn-add" onclick="updateCart('${p.id}', 1)">Agregar</button>
                            `}
                        </div>
                    </div>
                `;
            }).join('');
            updateUI();
        }
        function updateCart(id, delta) {
            cart[id] = (cart[id] || 0) + delta;
            if (cart[id] <= 0) delete cart[id];
            localStorage.setItem('{{STORAGE_KEY}}', JSON.stringify(cart));
            renderGrid();
        }
        function updateUI() {
            const count = Object.values(cart).reduce((a, b) => a + b, 0);
            const total = Object.keys(cart).reduce((sum, id) => {
                const p = products.find(prod => prod.id === id);
                return sum + (p ? p.price * cart[id] : 0);
            }, 0);
            const countEl = document.getElementById('cartCount');
            if (countEl) {
                countEl.innerText = count;
                countEl.classList.toggle('active', count > 0);
            }
            const cartTotal = document.getElementById('cartTotal');
            if (cartTotal) cartTotal.innerText = `L. ${total.toLocaleString()}`;
            const pillTotalText = document.getElementById('pillTotalText');
            if (pillTotalText) pillTotalText.innerText = `L. ${total.toLocaleString()}`;
            const floatPill = document.getElementById('floatPill');
            if (floatPill) floatPill.classList.toggle('active', count > 0);
            renderCart();
        }
        function renderCart() {
            const container = document.getElementById('cartItems');
            if (!container) return;
            const items = Object.keys(cart).map(id => {
                const p = products.find(prod => prod.id === id);
                if (!p) return '';
                return `
                    <div class="cart-item">
                        <img src="${p.img}" class="item-img">
                        <div style="flex:1">
                            <h4 style="font-size:0.9rem; margin-bottom:5px">${p.name}</h4>
                            <p style="color:var(--purple); font-weight:600">L. ${p.price.toLocaleString()}</p>
                            <div style="display:flex; align-items:center; gap:10px; margin-top:10px">
                                <button onclick="updateCart('${p.id}', -1)" style="background:none; border:1px solid #333; color:#fff; width:24px; height:24px; border-radius:50%; cursor:pointer">-</button>
                                <span>${cart[id]}</span>
                                <button onclick="updateCart('${p.id}', 1)" style="background:none; border:1px solid #333; color:#fff; width:24px; height:24px; border-radius:50%; cursor:pointer">+</button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            container.innerHTML = items || '<p style="text-align:center; opacity:0.5; margin-top:40px">Tu bolsa está vacía</p>';
        }
        function toggleCart(show) {
            const sidebar = document.getElementById('cartSidebar');
            const overlay = document.getElementById('cartOverlay');
            if (sidebar) sidebar.classList.toggle('open', show);
            if (overlay) overlay.classList.toggle('open', show);
        }
        function openProductModal(id) {
            const p = products.find(prod => prod.id === id);
            if (!p || p.name === "Cargando...") return;
            const content = document.getElementById('modalContent');
            if (content) {
                content.innerHTML = `
                    <button class="close-product" onclick="closeProductModal()"><i class="fa-solid fa-xmark"></i></button>
                    <img src="${p.img}" class="modal-img">
                    <div class="modal-body">
                        <h2 class="modal-name">${p.name}</h2>
                        <p class="modal-description">${p.desc}</p>
                        <p class="modal-cost">L. ${p.price.toLocaleString()}</p>
                        <button class="btn-wa" style="border-radius:30px" onclick="updateCart('${p.id}', 1); closeProductModal(); toggleCart(true)">Agregar a la bolsa</button>
                    </div>
                `;
            }
            const modal = document.getElementById('productModal');
            if (modal) modal.classList.add('active');
        }
        function closeProductModal() { 
            const modal = document.getElementById('productModal');
            if (modal) modal.classList.remove('active'); 
        }
        function openWaModal() { 
            const modal = document.getElementById('modalWa');
            if (modal) modal.classList.add('active'); 
        }
        function closeWaModal() { 
            const modal = document.getElementById('modalWa');
            if (modal) modal.classList.remove('active'); 
        }
        function sendToWA(phone) {
            const cartTotal = document.getElementById('cartTotal');
            const totalText = cartTotal ? cartTotal.innerText : "0";
            const text = encodeURIComponent("¡Hola! Me gustaría comprar:\\n\\n" + 
                Object.keys(cart).map(id => {
                    const p = products.find(prod => prod.id === id);
                    return `- ${p.name} (Cant: ${cart[id]})`;
                }).join('\\n') + 
                "\\n\\nTotal: " + totalText);
            window.open(`https://wa.me/${phone}?text=${text}`);
        }
        window.onload = loadProducts;
    </script>
</body>
</html>"""

files = [
    # MUJER (New Structure)
    {"path": "../prendas/mujer/vestidos.html", "title": "Vestidos", "loader": "VESTIDOS", "hero": "Vestidos", "prefix": "VM", "category": "Vestidos", "storage": "alexa_cart_m_vestidos", "home": "../../index.html"},
    {"path": "../prendas/mujer/faldas.html", "title": "Faldas", "loader": "FALDAS", "hero": "Faldas", "prefix": "FM", "category": "Faldas", "storage": "alexa_cart_m_faldas", "home": "../../index.html"},
    {"path": "../prendas/mujer/camisas.html", "title": "Camisas", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CM", "category": "Camisas", "storage": "alexa_cart_m_camisas", "home": "../../index.html"},
    {"path": "../prendas/mujer/calzado.html", "title": "Calzado", "loader": "CALZADO", "hero": "Calzado", "prefix": "CMM", "category": "Calzado", "storage": "alexa_cart_m_calzado", "home": "../../index.html"},

    # HOMBRE (New Structure)
    {"path": "../prendas/mujer/hombre/formal.html", "title": "Formal Hombre", "loader": "FORMAL", "hero": "Colección Formal", "prefix": "FH", "category": "Formal", "storage": "alexa_cart_h_formal", "home": "../../../index.html"},
    {"path": "../prendas/mujer/hombre/camisas.html", "title": "Camisas Hombre", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CH", "category": "Camisas", "storage": "alexa_cart_h_camisas", "home": "../../../index.html"},
    {"path": "../prendas/mujer/hombre/calzado.html", "title": "Calzado Hombre", "loader": "CALZADO", "hero": "Calzado", "prefix": "CHM", "category": "Calzado", "storage": "alexa_cart_h_calzado", "home": "../../../index.html"},
    {"path": "../prendas/mujer/hombre/pantalones.html", "title": "Pantalones Hombre", "loader": "PANTALONES", "hero": "Pantalones", "prefix": "PH", "category": "Pantalones", "storage": "alexa_cart_h_pantalones", "home": "../../../index.html"},

    # NIÑAS (New Structure)
    {"path": "../prendas/mujer/niñas/vestidos.html", "title": "Vestidos Niñas", "loader": "VESTIDOS", "hero": "Vestidos", "prefix": "VNM", "category": "Vestidos", "storage": "alexa_cart_n_vestidos", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niñas/faldas.html", "title": "Faldas Niñas", "loader": "FALDAS", "hero": "Faldas", "prefix": "FNM", "category": "Faldas", "storage": "alexa_cart_n_faldas", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niñas/camisas.html", "title": "Camisas Niñas", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CNM", "category": "Camisas", "storage": "alexa_cart_n_camisas", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niñas/calzado.html", "title": "Calzado Niñas", "loader": "CALZADO", "hero": "Calzado", "prefix": "CANM", "category": "Calzado", "storage": "alexa_cart_n_calzado", "home": "../../../index.html"},

    # NIÑOS (New Structure)
    {"path": "../prendas/mujer/niños/pantalones.html", "title": "Pantalones Niños", "loader": "PANTALONES", "hero": "Pantalones", "prefix": "PNO", "category": "Pantalones", "storage": "alexa_cart_no_pantalones", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niños/camisas.html", "title": "Camisas Niños", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CNO", "category": "Camisas", "storage": "alexa_cart_no_camisas", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niños/calzado.html", "title": "Calzado Niños", "loader": "CALZADO", "hero": "Calzado", "prefix": "CANO", "category": "Calzado", "storage": "alexa_cart_no_calzado", "home": "../../../index.html"},
    {"path": "../prendas/mujer/niños/shorts.html", "title": "Shorts Niños", "loader": "SHORTS", "hero": "Shorts", "prefix": "SNO", "category": "Shorts", "storage": "alexa_cart_no_shorts", "home": "../../../index.html"},

    # HOMBRE (Original Structure)
    {"path": "../prendas/hombre/formal.html", "title": "Formal Hombre", "loader": "FORMAL", "hero": "Colección Formal", "prefix": "FH", "category": "Formal", "storage": "alexa_cart_h_formal", "home": "../../index.html"},
    {"path": "../prendas/hombre/camisas.html", "title": "Camisas Hombre", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CH", "category": "Camisas", "storage": "alexa_cart_h_camisas", "home": "../../index.html"},
    {"path": "../prendas/hombre/calzado.html", "title": "Calzado Hombre", "loader": "CALZADO", "hero": "Calzado", "prefix": "CHM", "category": "Calzado", "storage": "alexa_cart_h_calzado", "home": "../../index.html"},
    {"path": "../prendas/hombre/pantalones.html", "title": "Pantalones Hombre", "loader": "PANTALONES", "hero": "Pantalones", "prefix": "PH", "category": "Pantalones", "storage": "alexa_cart_h_pantalones", "home": "../../index.html"},

    # NIÑAS (Original Structure)
    {"path": "../prendas/niñas/vestidos.html", "title": "Vestidos Niñas", "loader": "VESTIDOS", "hero": "Vestidos", "prefix": "VNM", "category": "Vestidos", "storage": "alexa_cart_n_vestidos", "home": "../../index.html"},
    {"path": "../prendas/niñas/faldas.html", "title": "Faldas Niñas", "loader": "FALDAS", "hero": "Faldas", "prefix": "FNM", "category": "Faldas", "storage": "alexa_cart_n_faldas", "home": "../../index.html"},
    {"path": "../prendas/niñas/camisas.html", "title": "Camisas Niñas", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CNM", "category": "Camisas", "storage": "alexa_cart_n_camisas", "home": "../../index.html"},
    {"path": "../prendas/niñas/calzado.html", "title": "Calzado Niñas", "loader": "CALZADO", "hero": "Calzado", "prefix": "CANM", "category": "Calzado", "storage": "alexa_cart_n_calzado", "home": "../../index.html"},

    # NIÑOS (Original Structure)
    {"path": "../prendas/niños/pantalones.html", "title": "Pantalones Niños", "loader": "PANTALONES", "hero": "Pantalones", "prefix": "PNO", "category": "Pantalones", "storage": "alexa_cart_no_pantalones", "home": "../../index.html"},
    {"path": "../prendas/niños/camisas.html", "title": "Camisas Niños", "loader": "CAMISAS", "hero": "Camisas", "prefix": "CNO", "category": "Camisas", "storage": "alexa_cart_no_camisas", "home": "../../index.html"},
    {"path": "../prendas/niños/calzado.html", "title": "Calzado Niños", "loader": "CALZADO", "hero": "Calzado", "prefix": "CANO", "category": "Calzado", "storage": "alexa_cart_no_calzado", "home": "../../index.html"},
    {"path": "../prendas/niños/shorts.html", "title": "Shorts Niños", "loader": "SHORTS", "hero": "Shorts", "prefix": "SNO", "category": "Shorts", "storage": "alexa_cart_no_shorts", "home": "../../index.html"}
]

for f in files:
    try:
        content = template.replace("{{TITLE}}", f["title"])
        content = content.replace("{{LOADER}}", f["loader"])
        content = content.replace("{{HERO_H1}}", f["hero"])
        content = content.replace("{{PREFIX}}", f["prefix"])
        content = content.replace("{{CATEGORY}}", f["category"])
        content = content.replace("{{STORAGE_KEY}}", f["storage"])
        content = content.replace("{{HOME_LINK}}", f["home"])
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(f["path"]), exist_ok=True)
        
        with open(f["path"], "w", encoding="utf-8") as file:
            file.write(content)
        print(f"Updated: {f['path']}")
    except Exception as e:
        print(f"Failed to update: {f['path']} - {str(e)}")
