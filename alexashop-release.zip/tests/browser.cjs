const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const origin=process.env.TEST_URL||'http://127.0.0.1:8765',root=path.resolve(process.argv[2]||'.');
const shots=process.env.QA_SCREENSHOTS||'/tmp/alexa-qa-shots';fs.mkdirSync(shots,{recursive:true});
function htmlFiles(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.name.startsWith('.')?[]:e.isDirectory()?htmlFiles(path.join(dir,e.name)):e.name.endsWith('.html')?[path.join(dir,e.name)]:[]);}
(async()=>{
 const browser=await chromium.launch({headless:true});let inspected=0;
 try{
  for(const width of [360,768,1440]){
   const context=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});
   await context.route('https://docs.google.com/**',r=>r.abort());
   const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
   for(const file of htmlFiles(root)){
    const route='/'+path.relative(root,file).split(path.sep).join('/');
    const response=await page.goto(origin+route,{waitUntil:'networkidle'});assert.equal(response.status(),200,route);
    await page.locator('h1').waitFor();
    const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);assert.equal(overflow,false,`horizontal overflow ${width}: ${route}`);
    assert.equal(errors.length,0,`${route}: ${errors.join('; ')}`);inspected++;
   }
   await page.goto(origin+'/',{waitUntil:'networkidle'});await page.screenshot({path:path.join(shots,`home-${width}.png`)});
   // The ticker has an explicit keyboard-operable pause control.
   if(width===1440){await page.emulateMedia({reducedMotion:'no-preference'});await page.getByRole('button',{name:'Pausar cinta',exact:true}).click();assert.equal(await page.locator('#pause-ticker').getAttribute('aria-pressed'),'true');}
   await context.close();
  }
  const context=await browser.newContext({viewport:{width:390,height:844},reducedMotion:'reduce'});await context.route('https://docs.google.com/**',r=>r.abort());const page=await context.newPage();
  await page.goto(origin+'/catalogo.html',{waitUntil:'networkidle'});
  await page.locator('[data-add]').first().click();await page.getByRole('button',{name:'Bolsa (1)',exact:true}).click();
  assert.ok(await page.locator('#bag-wa-1').getAttribute('href'));await page.locator('#bag-dialog [data-qty="1"]').click();assert.match(await page.locator('#bag-content').innerText(),/2/);
  await page.locator('#order-note').fill('</textarea><img src=x onerror=alert(1)>');assert.equal(await page.locator('#bag-content img[onerror]').count(),0);
  await page.getByRole('button',{name:'Cerrar bolsa',exact:true}).click();
  await page.goto(origin+'/redes.html',{waitUntil:'networkidle'});assert.equal(await page.getByRole('button',{name:'Bolsa (2)',exact:true}).count(),1);
  for(const audience of ['mujer','hombre']){
   await page.goto(origin+`/Detalles/${audience}/personalizar.html`,{waitUntil:'networkidle'});
   for(let step=0;step<6;step++){
    assert.equal(await page.locator('.gift-options img').count(),0);
    if(![3,4].includes(step))await page.locator('[data-pick]').first().click();
    if(step===5)await page.locator('#gift-message').fill('<img src=x onerror=alert(1)> Te quiero');
    await page.locator('#gift-next').click();await page.waitForLoadState('networkidle');
   }
   await page.locator('.summary-actions a').first().waitFor();assert.equal(await page.locator('.dedication img').count(),0);assert.match(await page.locator('.dedication').innerText(),/<img/);
   assert.match(await page.locator('.summary-actions a').first().getAttribute('href'),/^https:\/\/wa.me\//);
   await page.screenshot({path:path.join(shots,`gift-${audience}.png`)});
  }
  await page.goto(origin+'/catalogo.html',{waitUntil:'networkidle'});
  await page.evaluate(()=>localStorage.setItem('alexa_bag_v2',JSON.stringify({'unknown-id':1})));await page.reload({waitUntil:'networkidle'});await page.getByRole('button',{name:'Bolsa (1)',exact:true}).click();assert.equal(await page.locator('#bag-wa-1').getAttribute('href'),null);
  await page.getByRole('button',{name:'Cerrar bolsa',exact:true}).click();await page.goto(origin+'/privacidad.html',{waitUntil:'networkidle'});
  page.once('dialog',d=>d.accept());await page.locator('#clear-saved-data').click();assert.match(await page.locator('#privacy-feedback').innerText(),/se han borrado/);assert.equal(await page.evaluate(()=>Object.keys(localStorage).filter(k=>k.startsWith('alexa_')).length),0);
  const axe=require('axe-core');let audits=0;
  for(const route of ['/','/catalogo.html','/privacidad.html','/condiciones.html','/Detalles/mujer/personalizar.html']){
   await page.goto(origin+route,{waitUntil:'networkidle'});
   // Browser-scoped test instrumentation; this does not weaken the site's policy.
   await page.evaluate(axe.source);
   const report=await page.evaluate(async()=>axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));
   const violations=report.violations.filter(v=>['critical','serious'].includes(v.impact));assert.deepEqual(violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.target)})),[],route);audits++;
  }
  console.log(JSON.stringify({htmlViewportChecks:inspected,giftFlows:2,cart:'passed',privacyDeletion:'passed',xssRendering:'passed',accessibilityPages:audits,externalRequests:'blocked for repeatable fallback testing'}));await context.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
