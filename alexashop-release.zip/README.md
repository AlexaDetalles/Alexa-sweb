# AlexaShop · KROMBYTE

Código editable de Tiendas Alexa, publicado en https://alexashop.cc/. Sitio estático sin cuentas ni pagos dentro de la web.

## Desarrollo y pruebas

Servir esta carpeta con `python3 -m http.server 8765`. Pruebas de lógica: `node --test tests/core.test.mjs`.

`tests/browser.cjs` recorre los HTML a 360, 768 y 1440 px y comprueba la bolsa, personalización, almacenamiento y accesibilidad automatizada con Playwright y axe-core. Sus dependencias de QA se instalan solo en el ejecutor temporal; no se publican.

## Inventario y pedidos

`assets/data/sources.json` identifica las hojas públicas de inventario. Los CSV locales son el respaldo si la conexión falla. Los precios se calculan en centavos y se confirman con la tienda. `assets/gifts.mjs` conserva cuatro regalos por cotizar con imágenes ilustrativas. El personalizador usa únicamente texto.

## Producción y datos

Favicon SVG/ICO, iconos móviles, manifiesto, sitemap, política CSP y referrer están incorporados. Las imágenes de productos se limitan a copias locales conocidas. `privacidad.html` permite borrar bolsa, notas y regalos del navegador. `condiciones.html` identifica contactos y explica precio total, entrega y reclamos sin suprimir derechos del consumidor.

El repo privado es respaldo editable; no actualiza automáticamente el dominio. El repo original `AlexaDetalles/Alexa-sweb` publica con GitHub Pages el paquete revisado mediante su workflow. Ese flujo verifica el SHA-256 y las pruebas de lógica. Actualizar el ZIP requiere actualizar su SHA esperado; no reutilizar un paquete antiguo sobre cambios nuevos.

La información comercial, garantías y gestión de reclamos deben seguir siendo atendidas y confirmadas por Tiendas Alexa. Las comprobaciones automatizadas no certifican cumplimiento legal ni ausencia total de vulnerabilidades.
