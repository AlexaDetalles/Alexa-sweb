# AlexaShop · Tiendas Alexa

Tienda estática de perfumes, accesorios y regalos en Choluteca. Mantiene las rutas originales y el dominio `alexashop.cc`. No requiere servidor de aplicación, framework ni instalación de dependencias.

## Desarrollo

Desde la raíz del repositorio:

```sh
python3 -m http.server 8080
node --test tests/core.test.mjs
```

Abrir `http://localhost:8080`. Se debe servir la raíz, no abrir un HTML como archivo, porque los recursos usan rutas absolutas.

## Estructura

- Los HTML contienen navegación, contenido editorial y los puntos de entrada de cada colección.
- `assets/shop.css`: sistema visual y versiones móviles.
- `assets/shop.mjs`: catálogo, filtros, bolsa compartida, diálogos y personalización.
- `assets/core.mjs`: lector CSV, validación, precios en centavos y cálculos sin efectos secundarios.
- `assets/data/sources.json`: hojas públicas de inventario existentes.
- `assets/data/*.csv`: copia de los datos disponibles al preparar esta versión. Se intenta actualizar desde Google al cargar; si falla, se identifica la copia como referencia. Para renovar el respaldo, reemplazar estos CSV por la exportación de su misma hoja.
- `assets/images/*.webp`: fotografías originales optimizadas; los PNG originales permanecen en `img/`.
- `tests/core.test.mjs`: integridad del CSV, precios, validación y cambios de personalización.

## Inventario y pedidos

Las categorías del catálogo usan los códigos originales HP, MP, PHP, PMP, JYA, RLA, CTA, CMM, CHM, PAG y PAGH. Los renglones sin nombre o precio válido no se muestran. Se retiró la colección de calzado y se ocultan los renglones marcados como no disponibles. No se inventan existencias, reseñas ni descuentos.

La bolsa comparte referencias y cantidades entre colecciones y pestañas. Los precios y la disponibilidad se toman del catálogo al calcular, y los artículos retirados bloquean el enlace de pedido hasta quitarlos. Las selecciones de regalos para él y para ella son independientes. Los totales se recalculan desde las opciones válidas; cambiar de base o tamaño invalida las opciones dependientes.

Los enlaces preparan el mensaje en WhatsApp; el cliente debe enviarlo allí. No procesamos pagos ni declaramos pedidos confirmados en el navegador. La tienda confirma disponibilidad, precio final, presentación y entrega.

Los regalos preparados se definen en `assets/gifts.mjs`: cuatro propuestas por encargo con imágenes ilustrativas generadas para la tienda. Se pueden añadir a la bolsa y solicitar por WhatsApp. No tienen precio ni existencias inventadas: aparecen por cotizar y no se computan como un regalo gratuito. La actualización desde Google conserva estas propuestas locales.

Los tamaños sin contenido compatible se ocultan. Las opciones de personalización sin fotografía se presentan como tarjetas de texto, sin cuadros de imagen pendiente.

## Publicación y privacidad

La versión pública encontrada antes de la renovación proviene de `redestest-1` (GitHub Pages). `CNAME` conserva `alexashop.cc`. Revisar la configuración de Pages antes de cambiar la rama de publicación. `.nojekyll` permite servir los recursos directamente.

Esta versión no carga Clarity ni Google Analytics. La bolsa y las dedicatorias se guardan solamente en el almacenamiento del navegador hasta que el cliente abre WhatsApp. Consultar `privacidad.html` para la información mostrada al visitante.
